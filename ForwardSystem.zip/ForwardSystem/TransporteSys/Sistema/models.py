from django.db import models

from django.db import models

class Documentacion(models.Model):
    nombre_documento = models.CharField(max_length=100)
    tipo_documento = models.CharField(max_length=50)
    archivo = models.FileField(upload_to='documentos/')
    fecha_subida = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nombre_documento

from django.db import models

class Documento(models.Model):
    TIPO_DOCUMENTO_CHOICES = [
        ('factura_comercial', 'Factura Comercial'),
        ('lista_empaque', 'Lista de Empaque'),
        ('carta_porte', 'Carta Porte'),
        ('duca_f', 'Duca F'),
    ]

    tipo_documento = models.CharField(max_length=50, choices=TIPO_DOCUMENTO_CHOICES)
    archivo = models.FileField(upload_to='documentos/')
    fecha_subida = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.tipo_documento
