
    document.addEventListener("DOMContentLoaded", function() {
        var menuToggle = document.getElementById("menu-toggle");
        var sidebar = document.getElementById("sidebar");
        var mainContent = document.getElementById("main-content");

        menuToggle.addEventListener("click", function() {
            sidebar.classList.toggle("active");
            mainContent.classList.toggle("shifted");

            // Animación del botón
            this.classList.toggle("change");
        });

        // Cierra el menú si se hace clic fuera del menú cuando está abierto
        document.addEventListener("click", function(event) {
            if (!sidebar.contains(event.target) && !menuToggle.contains(event.target) && sidebar.classList.contains("active")) {
                sidebar.classList.remove("active");
                mainContent.classList.remove("shifted");
                menuToggle.classList.remove("change");
            }
        });
    });

