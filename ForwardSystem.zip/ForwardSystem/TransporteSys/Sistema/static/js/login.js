document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('login-form');

    form.addEventListener('submit', function(event) {
        event.preventDefault();  // Previene el envío normal del formulario

        // Simula una validación de contraseña incorrecta
        const passwordCorrect = false;  // Cambia esto a true para simular una contraseña correcta

        if (passwordCorrect) {
            // Mostrar pantalla de carga con ruedita
            Swal.fire({
                title: 'Iniciando sesión...',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            // Simula un retraso para la pantalla de carga
            setTimeout(() => {
                // Redirige al home después de iniciar sesión exitosamente
                window.location.href = '/home/';
            }, 2000);  // Simula 2 segundos de carga
        } else {
            // Mostrar alerta de error
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Usuario o contraseña incorrectos',
                confirmButtonText: 'Intentar de nuevo'
            });
        }
    });
});
