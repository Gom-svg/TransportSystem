document.addEventListener('DOMContentLoaded', function () {
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main-content');
    const openBtn = document.getElementById('open-btn');
    const closeBtn = document.getElementById('close-btn');

    openBtn.addEventListener('click', function () {
        sidebar.style.left = '0';
        mainContent.style.marginLeft = '250px'; // Ajusta el contenido principal al abrir el menú
    });

    closeBtn.addEventListener('click', function () {
        sidebar.style.left = '-250px';
        mainContent.style.marginLeft = '0'; // Restaura el margen cuando se cierra el menú
    });

    // Arrastrar y soltar archivos
    const dragDropArea = document.getElementById('drag-drop-area');
    const fileInput = document.getElementById('file-input');

    dragDropArea.addEventListener('dragover', function (e) {
        e.preventDefault();
        dragDropArea.classList.add('dragging');
    });

    dragDropArea.addEventListener('dragleave', function (e) {
        e.preventDefault();
        dragDropArea.classList.remove('dragging');
    });

    dragDropArea.addEventListener('drop', function (e) {
        e.preventDefault();
        dragDropArea.classList.remove('dragging');
        fileInput.files = e.dataTransfer.files;
    });

    dragDropArea.addEventListener('click', function () {
        fileInput.click();
    });

    fileInput.addEventListener('change', function () {
        if (fileInput.files.length > 0) {
            dragDropArea.textContent = fileInput.files.length + ' archivos seleccionados';
        }
    });
});
