from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .forms import DocumentacionForm, DocumentoForm
from .models import Documento

def home(request):
    return render(request, 'home.html')

def custom_login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Redirige al home si las credenciales son correctas
        else:
            messages.error(request, 'Usuario o contraseña incorrectos.')  # Muestra un mensaje de error
    return render(request, 'login.html')

def documentacion_view(request):
    if request.method == 'POST':
        form = DocumentacionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')  # Redirigir al home después de subir
    else:
        form = DocumentacionForm()
    return render(request, 'documentacion_form.html', {'form': form})

def visualizar_informacion_view(request):
    documentos = Documento.objects.all()
    return render(request, 'visualizar_informacion.html', {'documentos': documentos})

def eliminar_documento_view(request, id):
    documento = get_object_or_404(Documento, id=id)
    documento.delete()
    return redirect('visualizar_informacion')

def AgregarDatos_view(request):
    if request.method == 'POST':
        form = DocumentoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('visualizar_informacion')
    else:
        form = DocumentoForm()
    return render(request, 'AgregarDatos.html', {'form': form})
