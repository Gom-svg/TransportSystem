from django import forms
from .models import Documentacion
from django import forms
from .models import Documento

class DocumentacionForm(forms.ModelForm):
    class Meta:
        model = Documentacion
        fields = ['nombre_documento', 'tipo_documento', 'archivo']



class DocumentoForm(forms.ModelForm):
    class Meta:
        model = Documento
        fields = ['tipo_documento', 'archivo']
