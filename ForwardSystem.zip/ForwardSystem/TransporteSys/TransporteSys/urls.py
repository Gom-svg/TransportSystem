from django.contrib import admin
from django.urls import path
from django.shortcuts import redirect
from django.contrib.auth import views as auth_views
from Sistema import views
from django.conf import settings
from django.conf.urls.static import static
from Sistema.views import AgregarDatos_view
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', lambda request: redirect('login')),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('home/', views.home, name='home'),
    
    path('password_reset/', auth_views.PasswordResetView.as_view(template_name='forgot_account.html'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    
    # Rutas para la documentación
    path('documentacion/', views.documentacion_view, name='documentacion'),
    path('AgregarDatos/', views.AgregarDatos_view, name='AgregarDatos'),
    path('visualizar-informacion/', views.visualizar_informacion_view, name='visualizar_informacion'),
    
    # Ruta para eliminar documentos
    path('eliminar-documento/<int:id>/', views.eliminar_documento_view, name='eliminar_documento'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
